exports.id = 193;
exports.ids = [193];
exports.modules = {

/***/ 4950:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 3481, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 6088));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 2319));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 7977, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 7649, 23))

/***/ }),

/***/ 6088:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* __next_internal_client_entry_do_not_use__ default auto */ 

const AdSense = ()=>{
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        // Load the AdSense script asynchronously
        const script = document.createElement("script");
        script.src = "https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-8409124849421096";
        script.async = true;
        document.body.appendChild(script);
    }, []);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {}); // Empty fragment as this component doesn't render anything
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AdSense);


/***/ }),

/***/ 2319:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Navbar)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9483);
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_navigation__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8421);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1621);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _headlessui_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9229);
/* harmony import */ var _heroicons_react_24_outline__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1966);
/* harmony import */ var _heroicons_react_24_outline__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4832);
/* harmony import */ var _heroicons_react_20_solid__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6370);
/* __next_internal_client_entry_do_not_use__ default auto */ 








const navigation = [
    {
        name: "Home",
        href: "/",
        current: false
    },
    {
        name: "Courses",
        href: "/courses",
        current: false
    },
    {
        name: "Quiz",
        href: "https://www.urduitacademy.com/quiz/",
        current: false,
        external: true
    },
    {
        name: "About",
        href: "/about",
        current: false
    },
    {
        name: "Help",
        href: "/help",
        current: false
    },
    {
        name: "Blog",
        href: "/blogs",
        current: false
    },
    {
        name: "FAQs",
        href: "/faq",
        current: false
    }
];
function classNames(...classes) {
    return classes.filter(Boolean).join(" ");
}
function Navbar() {
    const pathname = (0,next_navigation__WEBPACK_IMPORTED_MODULE_2__.usePathname)();
    const router = (0,next_navigation__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const [query, setQuery] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const handleKeyPress = (event)=>{
        if (event.key === "Enter") {
            router.push(`/search-result?query=${encodeURIComponent(query)}`);
        }
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_5__/* .Disclosure */ .p, {
            as: "nav",
            className: "border-b border-[#EEEEEE] bg-white",
            children: ({ open  })=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "mx-auto max-w-[1215px] px-4",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex h-[88px] justify-between pt-4",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "flex flex-shrink-0 items-center",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    href: "/",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                        src: "/logo.png",
                                                        alt: "Urdu IT Academy",
                                                        width: 144,
                                                        height: 38,
                                                        className: "cursor-pointer"
                                                    })
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "hidden lg:-my-px lg:ml-[45px] lg:flex lg:space-x-[30px]",
                                                children: navigation.map((item)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react__WEBPACK_IMPORTED_MODULE_1___default().Fragment), {
                                                        children: item.external ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                            href: item.href,
                                                            target: "_blank" // Open the Quiz link in a new tab
                                                            ,
                                                            rel: "noopener noreferrer" // For security reasons
                                                            ,
                                                            className: classNames(item.current ? "border-[#0063F6] text-gray-900 font-bold" : "border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700", "inline-flex items-center border-b-4 px-1 pt-1 text-base font-normal cursor-pointer"),
                                                            children: item.name
                                                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                            href: item.href,
                                                            className: classNames(pathname === item.href ? "border-[#0063F6] text-gray-900 font-bold" : "border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700", "inline-flex items-center border-b-4 px-1 pt-1 text-base font-normal cursor-pointer"),
                                                            "aria-current": pathname === item.href ? "page" : undefined,
                                                            children: item.name
                                                        }, item.name)
                                                    }, item.name))
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "-mr-2 flex items-center lg:hidden",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_headlessui_react__WEBPACK_IMPORTED_MODULE_5__/* .Disclosure */ .p.Button, {
                                            className: "inline-flex items-center justify-center rounded-md bg-white p-2 text-gray-400 hover:bg-gray-100 hover:text-gray-500 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: "sr-only",
                                                    children: "Open main menu"
                                                }),
                                                open ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_heroicons_react_24_outline__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                                    className: "block h-6 w-6",
                                                    "aria-hidden": "true"
                                                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_heroicons_react_24_outline__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                    className: "block h-6 w-6",
                                                    "aria-hidden": "true"
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "mdlg:w-[380px] hidden lg:flex items-center",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                htmlFor: "search",
                                                className: "sr-only",
                                                children: "Search"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "w-full relative text-gray-400 focus-within:text-gray-600",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "cursor-pointer absolute inset-y-0 left-0 flex items-center pl-3",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                            className: `${query === "" ? "cursor-not-allowed" : "cursor-pointer"}`,
                                                            onClick: (e)=>{
                                                                if (query === "") {
                                                                    e.preventDefault();
                                                                }
                                                            },
                                                            href: {
                                                                pathname: "/search-result",
                                                                query: {
                                                                    query
                                                                }
                                                            },
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_heroicons_react_20_solid__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                                                className: "h-5 w-5",
                                                                "aria-hidden": "true"
                                                            })
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                        id: "search",
                                                        className: "block w-full rounded-md border border-[#E8E8E8] bg-white py-1.5 pl-10 pr-3 text-gray-900 sm:text-sm sm:leading-6 outline-none",
                                                        placeholder: "Search",
                                                        type: "search",
                                                        name: "search",
                                                        value: query,
                                                        onChange: (e)=>setQuery(e.target.value),
                                                        onKeyPress: handleKeyPress
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_headlessui_react__WEBPACK_IMPORTED_MODULE_5__/* .Disclosure */ .p.Panel, {
                            className: "lg:hidden",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "space-y-1 pb-3 pt-2",
                                    children: navigation.map((item)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_5__/* .Disclosure */ .p.Button, {
                                            as: "a",
                                            href: item.href,
                                            className: classNames(pathname === item.href ? "border-[#0063F6] bg-indigo-50 text-[#0063F6]" : "border-transparent text-gray-600 hover:border-gray-300 hover:bg-gray-50 hover:text-gray-800", "block border-l-4 py-2 pl-3 pr-4 text-base font-medium"),
                                            "aria-current": pathname === item.href ? "page" : undefined,
                                            children: item.name
                                        }, item.name))
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "flex lg:hidden items-center",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            htmlFor: "search",
                                            className: "sr-only",
                                            children: "Search"
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "w-full relative text-gray-400 focus-within:text-gray-600",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                    className: `${query === "" ? "cursor-not-allowed" : "cursor-pointer"}`,
                                                    onClick: (e)=>{
                                                        if (query === "") {
                                                            e.preventDefault();
                                                        }
                                                    },
                                                    href: {
                                                        pathname: "/search-results",
                                                        query: {
                                                            query
                                                        }
                                                    },
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "cursor-pointer absolute inset-y-0 left-0 flex items-center pl-3",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_heroicons_react_20_solid__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                                            className: "h-5 w-5",
                                                            "aria-hidden": "true"
                                                        })
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                    id: "search",
                                                    className: "block w-full rounded-md border border-[#E8E8E8] bg-white py-1.5 pl-10 pr-3 text-gray-900 sm:text-sm sm:leading-6 outline-none",
                                                    placeholder: "Search",
                                                    type: "search",
                                                    name: "search",
                                                    value: query,
                                                    onChange: (e)=>setQuery(e.target.value),
                                                    onKeyPress: handleKeyPress
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                })
        })
    });
}


/***/ }),

/***/ 4052:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ RootLayout),
  metadata: () => (/* binding */ metadata)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: ./node_modules/next/font/google/target.css?{"path":"app\\layout.js","import":"Inter","arguments":[{"subsets":["latin"]}],"variableName":"inter"}
var target_path_app_layout_js_import_Inter_arguments_subsets_latin_variableName_inter_ = __webpack_require__(8564);
var target_path_app_layout_js_import_Inter_arguments_subsets_latin_variableName_inter_default = /*#__PURE__*/__webpack_require__.n(target_path_app_layout_js_import_Inter_arguments_subsets_latin_variableName_inter_);
// EXTERNAL MODULE: ./node_modules/next/script.js
var script = __webpack_require__(1661);
var script_default = /*#__PURE__*/__webpack_require__.n(script);
// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(1313);
;// CONCATENATED MODULE: ./ui/Navbar.jsx

const proxy = (0,module_proxy.createProxy)(String.raw`D:\Codes\UitaUrduAcademy\urdu-it-academey\ui\Navbar.jsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const Navbar = (__default__);
// EXTERNAL MODULE: ./app/globals.css
var globals = __webpack_require__(2817);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(993);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(4834);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./ui/Footer.jsx



const navigation = {
    about: [
        {
            name: "Our Mission",
            href: "/about"
        },
        {
            name: "Our Team",
            href: "/about"
        },
        {
            name: "Our Partners",
            href: "/about"
        }
    ],
    courses: [
        {
            name: "New Courses",
            href: "/courses"
        },
        {
            name: "Course Active",
            href: "/courses"
        }
    ],
    help: [
        {
            name: "License agreement",
            href: "/license"
        },
        {
            name: "FAQ",
            href: "#"
        },
        {
            name: "Contact us",
            href: "/contact"
        }
    ],
    contribute: [
        {
            name: "Volunteer",
            href: "/contact"
        },
        {
            name: "Donate",
            href: "/contact"
        }
    ],
    social: [
        {
            id: 1,
            name: "Twitter",
            href: "https://twitter.com/UrduITacademy",
            alt: "Twitter Logo",
            icon: "/twitter_icon.png"
        },
        {
            id: 2,
            name: "Facebook",
            href: "https://www.facebook.com/urduitacademy/",
            alt: "Facebook Logo",
            icon: "/FacebookLogo(1).png"
        },
        {
            id: 3,
            name: "Youtube",
            href: "https://www.youtube.com/user/sama1119",
            alt: "Youtube Logo",
            icon: "/youtube_icon.png"
        },
        {
            id: 4,
            name: "Linedin",
            href: "https://www.linkedin.com/company/urdu-it-academy/",
            alt: "Linkedin Logo",
            icon: "/linkedin_icon.png"
        }
    ]
};
function Footer() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("footer", {
        className: "bg-[#F8F8F8] mt-14 lg:mt-20",
        "aria-labelledby": "footer-heading",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                id: "footer-heading",
                className: "sr-only",
                children: "Footer"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "mx-auto max-w-[1215px] px-4 py-8",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "xl:grid xl:grid-cols-3 gap-[160px]",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "mt-16 grid grid-cols-2 gap-4 sm:gap-[72px] xl:col-span-2 xl:mt-0",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "md:grid md:grid-cols-2 md:gap-[72px]",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "h-[158px] sm:h-auto",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                                        className: "md:text-lg text-base font-bold leading-[21.78px] text-[#686868]",
                                                        children: "About"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                                                        role: "list",
                                                        className: "mt-6 space-y-2",
                                                        children: navigation.about.map((item)=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                    href: item.href,
                                                                    className: "text-base font-normal leading-[19.36px] text-[#686868]",
                                                                    children: item.name
                                                                })
                                                            }, item.name))
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "mt-10 md:mt-0",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                                        className: "md:text-lg text-base font-bold leading-[21.78px] text-[#686868]",
                                                        children: "Courses"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                                                        role: "list",
                                                        className: "mt-6 space-y-2",
                                                        children: navigation.courses.map((item)=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                    href: item.href,
                                                                    className: "text-base font-normal leading-[19.36px] text-[#686868]",
                                                                    children: item.name
                                                                })
                                                            }, item.name))
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "md:grid md:grid-cols-2 md:gap-[72px]",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                                        className: "md:text-lg text-base font-bold leading-[21.78px] text-[#686868]",
                                                        children: "Help & Support"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                                                        role: "list",
                                                        className: "mt-6 space-y-2",
                                                        children: navigation.help.map((item)=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                    href: item.href,
                                                                    className: "text-base md:whitespace-nowrap font-normal leading-[19.36px] text-[#686868]",
                                                                    children: item.name
                                                                })
                                                            }, item.name))
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "mt-10 md:mt-0",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                                        className: "md:text-lg text-base font-bold leading-[21.78px] text-[#686868]",
                                                        children: "Contribute"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                                                        role: "list",
                                                        className: "mt-6 space-y-2",
                                                        children: navigation.contribute.map((item)=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                    href: item.href,
                                                                    className: "text-base font-normal leading-[19.36px] text-[#686868]",
                                                                    children: item.name
                                                                })
                                                            }, item.name))
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "space-y-[26px]",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                        className: "md:text-lg text-base font-bold leading-[21.78px] text-[#686868] mt-4",
                                        children: "Follow Us"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "flex space-x-6",
                                        children: navigation.social.map((item)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                                target: "_blank",
                                                href: item.href,
                                                className: "text-gray-500 hover:text-gray-400",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: "sr-only",
                                                        children: item.name
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                        src: item.icon,
                                                        alt: item.alt,
                                                        width: "0",
                                                        height: "0",
                                                        sizes: "100vw",
                                                        className: "w-6 h-auto"
                                                    })
                                                ]
                                            }, item.id))
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "mt-8",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "text-xs font-normal text-[#686868]",
                            children: "2023 \xa9 Urdu IT Academy | All rights reserved"
                        })
                    })
                ]
            })
        ]
    });
}

;// CONCATENATED MODULE: ./components/Adsense.js

const Adsense_proxy = (0,module_proxy.createProxy)(String.raw`D:\Codes\UitaUrduAcademy\urdu-it-academey\components\Adsense.js`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: Adsense_esModule, $$typeof: Adsense_$$typeof } = Adsense_proxy;
const Adsense_default_ = Adsense_proxy.default;


/* harmony default export */ const Adsense = (Adsense_default_);
;// CONCATENATED MODULE: ./app/layout.js







const metadata = {
    title: "Home - Urdu It Academy"
};
function RootLayout({ children  }) {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("html", {
        lang: "en",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("head", {
                children: /*#__PURE__*/ jsx_runtime_.jsx((script_default()), {
                    async: true,
                    src: "https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-8409124849421096",
                    crossOrigin: "anonymous",
                    strategy: "beforeInteractive"
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("body", {
                className: (target_path_app_layout_js_import_Inter_arguments_subsets_latin_variableName_inter_default()).className,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(Navbar, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx("main", {
                        className: "overflow-hidden mx-auto max-w-[1215px] px-4",
                        children: children
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Footer, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(Adsense, {})
                ]
            })
        ]
    });
}


/***/ }),

/***/ 3174:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3180);
/* harmony import */ var next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__);
  

  /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props) => {
    const imageData = {"type":"image/x-icon","sizes":"any"}
    const imageUrl = (0,next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__.fillMetadataSegment)(".", props.params, "favicon.ico")

    return [{
      ...imageData,
      url: imageUrl + "",
    }]
  });

/***/ }),

/***/ 2817:
/***/ (() => {



/***/ })

};
;