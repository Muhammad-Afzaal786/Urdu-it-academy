"use strict";
exports.id = 19;
exports.ids = [19];
exports.modules = {

/***/ 1825:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  SC: () => (/* binding */ SC)
});

// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(8038);
;// CONCATENATED MODULE: ./app/Apicall/authHeader.jsx
/* __next_internal_client_entry_do_not_use__ authHeader auto */ function authHeader() {
    // return authorization header with jwt token
    let AdminUser = JSON.parse(localStorage.getItem("userData"));
    if (AdminUser && AdminUser.accessToken) {
        var allowedOrigins = "*";
        var allow_headers = "Referer,Accept,Origin,User-Agent,Content-Type";
        return {
            Authorization: "Bearer " + AdminUser.accessToken,
            "Content-Type": "application/json, multipart/form-data",
            "Access-Control-Allow-Origin": allowedOrigins,
            "Access-Control-Allow-Methods": "PUT,GET,POST,DELETE,OPTIONS",
            "Access-Control-Allow-Headers": "Content-Type, Authorization",
            "Access-Control-Allow-Headers": allow_headers,
            "WWW-Authenticate": "Basic",
            "Access-Control-Allow-Credentials": true
        };
    }
}

;// CONCATENATED MODULE: ./app/Apicall/basePathApi.jsx
/* __next_internal_client_entry_do_not_use__ basePathApi auto */ //EOD_MOT api base url
const basePathApi = "https://dinovaux.ai/uitasite/public/"; // export const basePathApi = "https://apieod-sc.ascend.com.sa/api/";
 // export const basePathApi =
 //   "http://10.10.10.223/ticketing-system/public/api/v2/";
 // export const basePathApi = "https://nhcc.digitum.com.sa/api/v2/";

;// CONCATENATED MODULE: ./app/Apicall/ApiCall.jsx
/* __next_internal_client_entry_do_not_use__ baseUrl auto */ 
// let baseUrl = null;
// if ( process.env.NODE_ENV === 'development' )
// baseUrl = 'http://localhost:8000/api/';
// else if ( process.env.NODE_ENV === 'staging' )
// baseUrl = basePathApi+'api/';
// else if ( process.env.NODE_ENV === 'production' )
// baseUrl = basePathApi+'api/';
// export baseUrl
// console.log('REACT_APP_API_URL', process.env.REACT_APP_API_URL)
// console.log('REACT_APP_ENV', process.env.REACT_APP_ENV)
const baseUrl = basePathApi;

// EXTERNAL MODULE: ./node_modules/axios/lib/axios.js + 46 modules
var axios = __webpack_require__(248);
;// CONCATENATED MODULE: ./app/Apicall/ServerCall.jsx
/* __next_internal_client_entry_do_not_use__ SC auto */ 



const SC = {
    getCall,
    postCall,
    putCall,
    deleteCall,
    postCallLoginAdmin
};
function getCall(url, page) {
    const requestOptions = {
        method: "GET",
        headers: authHeader()
    };
    return axios/* default */.Z.get(baseUrl + url, requestOptions).then((response)=>{
        return response;
    }).catch(function(error) {
        return Promise.reject(error);
    });
}
function postCall(url, data, callbackProgressUpload = null, source) {
    Date.prototype.toJSON = function() {
    // return moment(this).format();
    };
    const requestOptions = {
        method: "POST",
        headers: authHeader(),
        body: JSON.stringify(data),
        onUploadProgress: function(progressEvent) {
            // var percentCompleted = Math.round( (progressEvent.loaded * 100) / progressEvent.total );
            if (callbackProgressUpload) callbackProgressUpload(progressEvent);
        }
    };
    if (source) {
        requestOptions.cancelToken = source.token;
    }
    return axios/* default */.Z.post(baseUrl + url, data, requestOptions).then((response)=>{
        return response;
    }).catch(function(error) {
        return Promise.reject(error);
    });
}
function putCall(url, data) {
    const requestOptions = {
        method: "PUT",
        headers: authHeader(),
        body: JSON.stringify(data)
    };
    return axios/* default */.Z.put(baseUrl + url, data, requestOptions).then((response)=>{
        return response;
    }).catch(function(error) {
        return Promise.reject(error);
    });
}
function deleteCall(url) {
    const requestOptions = {
        method: "DELETE",
        headers: authHeader()
    };
    return axios/* default */.Z.delete(baseUrl + url, requestOptions).then((response)=>{
        return response;
    }).catch(function(error) {
        return Promise.reject(error);
    });
}
function postCallLoginAdmin(url, data) {
    const requestOptions = {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(data)
    };
    return axios/* default */.Z.post(baseUrl + url, data, requestOptions).then((response)=>{
        if (response.data) {
        // handleLogin(response.data);
        }
        return response;
    }).catch(function(error) {
        return Promise.reject(error);
    });
}


/***/ }),

/***/ 6861:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   L1: () => (/* binding */ addFaqData),
/* harmony export */   QI: () => (/* binding */ addHelpData),
/* harmony export */   t1: () => (/* binding */ newUploadData)
/* harmony export */ });
//END POINT OF Api's
const addHelpData = "api/help";
const addFaqData = "api/faq";
const newUploadData = "api/lectures";


/***/ })

};
;